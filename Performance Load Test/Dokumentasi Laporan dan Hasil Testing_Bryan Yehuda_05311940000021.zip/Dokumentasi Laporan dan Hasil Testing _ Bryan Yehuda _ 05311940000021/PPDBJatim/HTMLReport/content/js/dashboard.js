/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9888888888888889, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9, 500, 1500, "Homepage"], "isController": false}, {"data": [1.0, 500, 1500, "Ketentuan-1"], "isController": false}, {"data": [1.0, 500, 1500, "Ketentuan"], "isController": false}, {"data": [1.0, 500, 1500, "Ketentuan-0"], "isController": false}, {"data": [1.0, 500, 1500, "Prosedur-0"], "isController": false}, {"data": [1.0, 500, 1500, "Pagu-1"], "isController": false}, {"data": [1.0, 500, 1500, "Pagu-0"], "isController": false}, {"data": [1.0, 500, 1500, "Jadwal-0"], "isController": false}, {"data": [1.0, 500, 1500, "Prosedur-1"], "isController": false}, {"data": [1.0, 500, 1500, "Jadwal-1"], "isController": false}, {"data": [1.0, 500, 1500, "Prosedur"], "isController": false}, {"data": [1.0, 500, 1500, "Pengumuman-0"], "isController": false}, {"data": [1.0, 500, 1500, "Pengumuman-1"], "isController": false}, {"data": [1.0, 500, 1500, "Jadwal"], "isController": false}, {"data": [1.0, 500, 1500, "Pagu"], "isController": false}, {"data": [0.9, 500, 1500, "Homepage-1"], "isController": false}, {"data": [1.0, 500, 1500, "Homepage-0"], "isController": false}, {"data": [1.0, 500, 1500, "Pengumuman"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 450, 0, 0.0, 109.27333333333335, 38, 1492, 77.0, 134.0, 149.79999999999995, 1248.5500000000009, 81.99708454810497, 1745.7214889303934, 14.50252254919825], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Homepage", 25, 0, 0.0, 338.2799999999999, 112, 1492, 129.0, 1276.0000000000005, 1460.5, 1492.0, 5.222477543346564, 195.919409011385, 1.2036178713181533], "isController": false}, {"data": ["Ketentuan-1", 25, 0, 0.0, 99.2, 65, 264, 82.0, 185.40000000000026, 264.0, 264.0, 7.396449704142012, 328.03081083579883, 1.0184564534023668], "isController": false}, {"data": ["Ketentuan", 25, 0, 0.0, 147.67999999999995, 113, 325, 132.0, 232.20000000000033, 323.8, 325.0, 7.275902211874272, 327.6890142971479, 2.003715257566938], "isController": false}, {"data": ["Ketentuan-0", 25, 0, 0.0, 48.28, 40, 65, 45.0, 59.800000000000004, 63.8, 65.0, 7.460459564309161, 5.131397344076395, 1.0272703111011638], "isController": false}, {"data": ["Prosedur-0", 25, 0, 0.0, 48.72, 41, 67, 47.0, 61.80000000000001, 66.7, 67.0, 7.487271638215035, 5.1454519504342615, 1.0236504192872118], "isController": false}, {"data": ["Pagu-1", 25, 0, 0.0, 76.07999999999998, 61, 103, 72.0, 99.00000000000001, 102.7, 103.0, 7.297139521307647, 152.62195344424984, 0.9691513426736719], "isController": false}, {"data": ["Pagu-0", 25, 0, 0.0, 47.64, 39, 62, 48.0, 56.80000000000001, 61.7, 62.0, 7.372456502506636, 5.0331414958714245, 0.9791543792391625], "isController": false}, {"data": ["Jadwal-0", 25, 0, 0.0, 47.720000000000006, 38, 59, 48.0, 55.60000000000001, 58.7, 59.0, 7.4649148999701405, 5.119590269483427, 1.0060139220662885], "isController": false}, {"data": ["Prosedur-1", 25, 0, 0.0, 80.56, 68, 113, 80.0, 95.4, 108.79999999999998, 113.0, 7.4183976261127595, 309.61696726632044, 1.0142340504451037], "isController": false}, {"data": ["Jadwal-1", 25, 0, 0.0, 74.76, 59, 100, 75.0, 89.60000000000002, 99.4, 100.0, 7.363770250368188, 171.83271585051546, 0.9923831001472754], "isController": false}, {"data": ["Prosedur", 25, 0, 0.0, 129.44000000000003, 110, 166, 130.0, 145.60000000000002, 162.39999999999998, 166.0, 7.284382284382284, 309.029674752331, 1.991823280885781], "isController": false}, {"data": ["Pengumuman-0", 25, 0, 0.0, 49.92, 39, 86, 49.0, 58.400000000000006, 77.89999999999998, 86.0, 7.355104442483084, 5.062093170785525, 1.0199461238599588], "isController": false}, {"data": ["Pengumuman-1", 25, 0, 0.0, 72.16000000000001, 58, 101, 70.0, 89.80000000000001, 98.0, 101.0, 7.297139521307647, 148.33345875291886, 1.011908019556334], "isController": false}, {"data": ["Jadwal", 25, 0, 0.0, 122.48, 103, 148, 123.0, 138.4, 146.2, 148.0, 7.248477819657872, 174.11353381414904, 1.9536912873296608], "isController": false}, {"data": ["Pagu", 25, 0, 0.0, 123.83999999999999, 102, 156, 120.0, 149.60000000000002, 154.8, 156.0, 7.202535292422932, 155.56041351555749, 1.9131734370498414], "isController": false}, {"data": ["Homepage-1", 25, 0, 0.0, 281.00000000000006, 68, 1359, 79.0, 1190.2000000000003, 1340.3999999999999, 1359.0, 5.3717232488182205, 197.95429670713366, 0.6190071712505372], "isController": false}, {"data": ["Homepage-0", 25, 0, 0.0, 56.96000000000001, 40, 132, 48.0, 88.0, 118.79999999999997, 132.0, 5.319148936170213, 3.5291306515957444, 0.6129488031914894], "isController": false}, {"data": ["Pengumuman", 25, 0, 0.0, 122.2, 100, 168, 121.0, 148.00000000000003, 163.79999999999998, 168.0, 7.198387561186294, 151.28030071264038, 1.9964278001727613], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 450, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
